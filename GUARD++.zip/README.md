# GUARD++ — SLSU Exam Integrity (v3.0.0)

Chrome Manifest V3 extension for transparent, authorized integrity monitoring of Moodle quizzes on
`lms.southernleytestateu.edu.ph`. **It works for any quiz** — nothing is tied to a quiz ID.

## How it works

| Moment | What happens |
|---|---|
| Student opens `/mod/quiz/attempt.php?attempt=…&cmid=…` (or `summary.php`) | A session starts automatically for that attempt. Blocking turns on, already-open AI tabs are redirected, a notification and an on-page banner tell the student protection is active. |
| During the attempt | AI and answer-sharing sites redirect to the warning page (each attempt = 1 strike). Copy, cut, paste, drag-and-drop, right-click, text selection on questions, and dev-tools/print/save/view-source shortcuts are disabled in the quiz page and in the essay editor. Focus loss, tab hiding, bulk text insertion, and tab closing are logged. |
| Student submits | Protection ends on `review.php` for **that attempt**, or on `view.php` after the LMS confirms the attempt is finished (covers quizzes with review disabled). |
| Safety nets | Protection is released after `inactivityMinutes` with no quiz-page heartbeat, or after `maxSessionHours`, so blocking can never get stuck. |

3 restricted-site attempts flags the session `REVIEW REQUIRED`. Nothing is banned automatically.

## Settings (config.js)

Edit `config.js`: blocked categories/domains, strike threshold, enforcement toggles, timeouts, `testMode`.
After changing blocked domains run `node tools/sync-manifest.js` (keeps `host_permissions` in sync).

`testMode: true` shows manual Start/Stop buttons on a quiz info page for development. **Leave it `false` for real exams**, otherwise a student could press Stop.

## Install

1. Extract the ZIP. 2. Open `chrome://extensions`, enable Developer mode. 3. Load unpacked → select this folder.
4. In the extension's Details, allow it in Incognito if exams may be taken there (or block Incognito by policy).
5. Test with a test account and a test quiz first.

## What changed from v2.0.0

- No hard-coded quiz: IDs are read from the URL; one session per attempt; strikes survive closing and reopening the attempt.
- **Fixed:** strikes were likely never counted (the redirect hid the original URL). Now counted from the pre-redirect navigation, once per navigation.
- **Fixed:** duplicated listeners could start two sessions; lost events from concurrent writes (all storage writes are now serialized).
- **Fixed:** opening any old review page ended protection. Only the protected attempt's own review/finished state does.
- **Fixed:** the threshold event repeated after strike 3; trimming used to delete `SESSION_STARTED`.
- Added: copy/cut/paste/drop/right-click/selection blocking (including inside the essay editor iframe), shortcut blocking, bulk-insertion detection, on-page banner and toasts.
- Added: more blocked sites in categories, open-tab sweep, inactivity/max-length release, quiz-tab-closed log, dashboard summaries, per-session delete, safer CSV export, manual controls hidden unless `testMode`.

## Limitations (please read)

- Not tamper-proof: a student can disable the extension, use another browser/device, or Incognito without permission. Browser-level policy (managed install) is the real fix.
- Records live in the student's own browser; they can export or clear them. Instructor-grade evidence needs a server (see Next steps).
- Can't see other devices, screens, or AI built into the browser/OS (e.g. side-panel assistants, phone). Dev-tools shortcuts are best-effort; menus can still open them.
- Disabling text selection can affect screen-reader and assistive-tech users; provide an accommodation path (e.g. a config flag or exemption).
- Finish detection relies on Moodle's redirect behaviour; test with your own quiz settings.

## Next steps (recommended)

Managed install via Google Workspace/Chrome policy; a small backend that receives event batches so instructors see reports centrally; per-exam settings fetched from the server.

## Deployment

Get LMS-admin and university approval, give students clear notice, set a retention period, restrict report access, offer an appeal process, and require human review before any disciplinary action.
